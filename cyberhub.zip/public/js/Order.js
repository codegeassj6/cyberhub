"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["Order"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/Order.vue?vue&type=script&lang=js&":
/*!************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/Order.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

//import name from './

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  data: function data() {
    return {};
  },
  components: {},
  props: [],
  computed: {},
  methods: {},
  watch: {
    $data: {
      handler: function handler(val, oldVal) {
        console.log('watcher: ', val);
      },
      deep: true
    }
  },
  updated: function updated() {},
  mounted: function mounted() {}
});

/***/ }),

/***/ "./resources/js/components/Order.vue":
/*!*******************************************!*\
  !*** ./resources/js/components/Order.vue ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Order_vue_vue_type_template_id_8a00ae1a_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Order.vue?vue&type=template&id=8a00ae1a&scoped=true& */ "./resources/js/components/Order.vue?vue&type=template&id=8a00ae1a&scoped=true&");
/* harmony import */ var _Order_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Order.vue?vue&type=script&lang=js& */ "./resources/js/components/Order.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Order_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Order_vue_vue_type_template_id_8a00ae1a_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,
  _Order_vue_vue_type_template_id_8a00ae1a_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "8a00ae1a",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/Order.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/Order.vue?vue&type=script&lang=js&":
/*!********************************************************************!*\
  !*** ./resources/js/components/Order.vue?vue&type=script&lang=js& ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Order_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Order.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/Order.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Order_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/Order.vue?vue&type=template&id=8a00ae1a&scoped=true&":
/*!**************************************************************************************!*\
  !*** ./resources/js/components/Order.vue?vue&type=template&id=8a00ae1a&scoped=true& ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Order_vue_vue_type_template_id_8a00ae1a_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Order_vue_vue_type_template_id_8a00ae1a_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Order_vue_vue_type_template_id_8a00ae1a_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Order.vue?vue&type=template&id=8a00ae1a&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/Order.vue?vue&type=template&id=8a00ae1a&scoped=true&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/Order.vue?vue&type=template&id=8a00ae1a&scoped=true&":
/*!*****************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/Order.vue?vue&type=template&id=8a00ae1a&scoped=true& ***!
  \*****************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _vm._m(0)
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", [
      _c("div", { staticClass: "space-intro" }, [
        _c("div", { staticClass: "container" }, [
          _c("div", { staticClass: "row" }, [
            _c("div", { staticClass: "col-md-8" }, [
              _c(
                "div",
                { staticClass: "card shadow-0 border rounded-3 mb-2" },
                [
                  _c("div", { staticClass: "card-body" }, [
                    _c("div", { staticClass: "row" }, [
                      _c(
                        "div",
                        {
                          staticClass:
                            "col-md-12 col-lg-3 col-xl-3 mb-4 mb-lg-0",
                        },
                        [
                          _c(
                            "div",
                            {
                              staticClass:
                                "bg-image hover-zoom ripple rounded ripple-surface",
                            },
                            [
                              _c("img", {
                                staticClass: "w-100",
                                attrs: {
                                  src: "https://mdbcdn.b-cdn.net/img/Photos/Horizontal/E-commerce/Products/img%20(4).webp",
                                },
                              }),
                              _vm._v(" "),
                              _c("a", { attrs: { href: "#!" } }, [
                                _c("div", { staticClass: "hover-overlay" }, [
                                  _c("div", {
                                    staticClass: "mask",
                                    staticStyle: {
                                      "background-color":
                                        "rgba(253, 253, 253, 0.15)",
                                    },
                                  }),
                                ]),
                              ]),
                            ]
                          ),
                        ]
                      ),
                      _vm._v(" "),
                      _c("div", { staticClass: "col-md-6 col-lg-6 col-xl-6" }, [
                        _c("h5", [_vm._v("Quant trident shirts")]),
                        _vm._v(" "),
                        _c("div", { staticClass: "d-flex flex-row" }, [
                          _c("div", { staticClass: "text-danger mb-1 me-2" }, [
                            _c("i", { staticClass: "fa fa-star" }),
                            _vm._v(" "),
                            _c("i", { staticClass: "fa fa-star" }),
                            _vm._v(" "),
                            _c("i", { staticClass: "fa fa-star" }),
                            _vm._v(" "),
                            _c("i", { staticClass: "fa fa-star" }),
                          ]),
                          _vm._v(" "),
                          _c("span", [_vm._v("310")]),
                        ]),
                        _vm._v(" "),
                        _c(
                          "div",
                          { staticClass: "mt-1 mb-0 text-muted small" },
                          [
                            _c("span", [_vm._v("100% cotton")]),
                            _vm._v(" "),
                            _c("span", { staticClass: "text-primary" }, [
                              _vm._v(" • "),
                            ]),
                            _vm._v(" "),
                            _c("span", [_vm._v("Light weight")]),
                            _vm._v(" "),
                            _c("span", { staticClass: "text-primary" }, [
                              _vm._v(" • "),
                            ]),
                            _vm._v(" "),
                            _c("span", [_vm._v("Best finish"), _c("br")]),
                          ]
                        ),
                        _vm._v(" "),
                        _c("div", { staticClass: "mb-2 text-muted small" }, [
                          _c("span", [_vm._v("Unique design")]),
                          _vm._v(" "),
                          _c("span", { staticClass: "text-primary" }, [
                            _vm._v(" • "),
                          ]),
                          _vm._v(" "),
                          _c("span", [_vm._v("For men")]),
                          _vm._v(" "),
                          _c("span", { staticClass: "text-primary" }, [
                            _vm._v(" • "),
                          ]),
                          _vm._v(" "),
                          _c("span", [_vm._v("Casual"), _c("br")]),
                        ]),
                        _vm._v(" "),
                        _c("p", { staticClass: "text-truncate mb-4 mb-md-0" }, [
                          _vm._v(
                            "\n                                There are many variations of passages of Lorem Ipsum available, but the\n                                majority have suffered alteration in some form, by injected humour, or\n                                randomised words which don't look even slightly believable.\n                                "
                          ),
                        ]),
                      ]),
                      _vm._v(" "),
                      _c(
                        "div",
                        {
                          staticClass:
                            "col-md-6 col-lg-3 col-xl-3 border-sm-start-none border-start",
                        },
                        [
                          _c(
                            "div",
                            {
                              staticClass:
                                "d-flex flex-row align-items-center mb-1",
                            },
                            [
                              _c("h4", { staticClass: "mb-1 me-1" }, [
                                _vm._v("$13.99"),
                              ]),
                              _vm._v(" "),
                              _c("span", { staticClass: "text-danger" }, [
                                _c("s", [_vm._v("$20.99")]),
                              ]),
                            ]
                          ),
                          _vm._v(" "),
                          _c("h6", { staticClass: "text-success" }, [
                            _vm._v("Free shipping"),
                          ]),
                          _vm._v(" "),
                          _c(
                            "div",
                            { staticClass: "d-flex flex-column mt-4" },
                            [
                              _c(
                                "button",
                                {
                                  staticClass: "btn btn-primary btn-sm",
                                  attrs: { type: "button" },
                                },
                                [_vm._v("Details")]
                              ),
                              _vm._v(" "),
                              _c(
                                "button",
                                {
                                  staticClass:
                                    "btn btn-outline-primary btn-sm mt-2",
                                  attrs: { type: "button" },
                                },
                                [
                                  _vm._v(
                                    "\n                                    Add to wishlist\n                                "
                                  ),
                                ]
                              ),
                            ]
                          ),
                        ]
                      ),
                    ]),
                  ]),
                ]
              ),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-md-4" }, [
              _c("div", { staticClass: "card" }, [
                _vm._v("\n                        s\n                    "),
              ]),
            ]),
          ]),
        ]),
      ]),
    ])
  },
]
render._withStripped = true



/***/ })

}]);
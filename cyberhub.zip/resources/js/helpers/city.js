export default {
    list: 'yes',
}
